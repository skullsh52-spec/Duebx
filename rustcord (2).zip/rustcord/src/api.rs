use crate::models::*;
use reqwest::{header, Client, RequestBuilder, Response};
use serde::de::DeserializeOwned;
use std::{fmt, time::Duration};

const BASE: &str = "https://discord.com/api/v10";
const UA: &str = "DiscordBot (https://github.com/rustcord, 0.3)";
const MAX_IMAGE_BYTES: usize = 2_000_000;

pub struct ApiError {
    pub code: u16, // 0 = network / parse problem
    msg: String,
}

impl ApiError {
    fn net(e: reqwest::Error) -> Self {
        Self { code: 0, msg: format!("Network error: {}", e.without_url()) }
    }
    fn parse(e: reqwest::Error) -> Self {
        Self { code: 0, msg: format!("Bad response: {}", e.without_url()) }
    }
    fn status(code: u16) -> Self {
        let msg = match code {
            401 => "Invalid or expired token".to_string(),
            403 => "Missing permission (403)".to_string(),
            404 => "Not found (404)".to_string(),
            429 => "Rate limited, try again shortly".to_string(),
            c => format!("Discord returned HTTP {c}"),
        };
        Self { code, msg }
    }
}

impl fmt::Display for ApiError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.msg)
    }
}

#[derive(Clone)]
pub struct Api {
    http: Client, // authenticated, Discord API only
    img: Client,  // no credentials, used for image downloads
}

impl Api {
    pub fn new(token: &str, bot: bool) -> Result<Self, String> {
        let auth = if bot { format!("Bot {token}") } else { token.to_string() };
        let mut value = header::HeaderValue::from_str(&auth)
            .map_err(|_| "Token has invalid characters".to_string())?;
        value.set_sensitive(true);
        let mut headers = header::HeaderMap::new();
        headers.insert(header::AUTHORIZATION, value);
        let http = Client::builder()
            .default_headers(headers)
            .user_agent(UA)
            .pool_max_idle_per_host(1)
            .build()
            .map_err(|e| e.to_string())?;
        let img = Client::builder()
            .user_agent(UA)
            .pool_max_idle_per_host(1)
            .timeout(Duration::from_secs(20))
            .build()
            .map_err(|e| e.to_string())?;
        Ok(Self { http, img })
    }

    /// Sends the request, retrying a few times when Discord rate-limits us.
    async fn call(&self, build: impl Fn() -> RequestBuilder) -> Result<Response, ApiError> {
        let mut tries = 0;
        loop {
            let resp = build().send().await.map_err(ApiError::net)?;
            let st = resp.status();
            if st.is_success() {
                return Ok(resp);
            }
            if st.as_u16() == 429 && tries < 3 {
                let wait = resp
                    .headers()
                    .get("retry-after")
                    .and_then(|v| v.to_str().ok())
                    .and_then(|s| s.parse::<f64>().ok())
                    .unwrap_or(1.0)
                    .clamp(0.1, 10.0);
                tries += 1;
                tokio::time::sleep(Duration::from_secs_f64(wait)).await;
                continue;
            }
            return Err(ApiError::status(st.as_u16()));
        }
    }

    async fn json<T: DeserializeOwned>(
        &self,
        build: impl Fn() -> RequestBuilder,
    ) -> Result<T, ApiError> {
        self.call(build).await?.json::<T>().await.map_err(ApiError::parse)
    }

    async fn get<T: DeserializeOwned>(&self, path: &str) -> Result<T, ApiError> {
        let url = format!("{BASE}{path}");
        self.json(|| self.http.get(&url)).await
    }

    pub async fn me(&self) -> Result<UserDto, ApiError> {
        self.get("/users/@me").await
    }

    pub async fn guilds(&self) -> Result<Vec<GuildDto>, ApiError> {
        self.get("/users/@me/guilds").await
    }

    pub async fn channels(&self, guild: &str) -> Result<Vec<ChannelDto>, ApiError> {
        self.get(&format!("/guilds/{guild}/channels")).await
    }

    pub async fn dms(&self) -> Result<Vec<DmDto>, ApiError> {
        self.get("/users/@me/channels").await
    }

    /// Newest first, capped at 50 to keep memory small.
    pub async fn messages(&self, ch: &str) -> Result<Vec<MessageDto>, ApiError> {
        self.get(&format!("/channels/{ch}/messages?limit=50")).await
    }

    pub async fn messages_before(&self, ch: &str, before: &str) -> Result<Vec<MessageDto>, ApiError> {
        self.get(&format!("/channels/{ch}/messages?limit=50&before={before}")).await
    }

    pub async fn message(&self, ch: &str, id: &str) -> Result<MessageDto, ApiError> {
        let mut m: MessageDto = self.get(&format!("/channels/{ch}/messages/{id}")).await?;
        m.channel_id = ch.to_string();
        Ok(m)
    }

    pub async fn send(
        &self,
        ch: &str,
        text: &str,
        reply: Option<&str>,
    ) -> Result<MessageDto, ApiError> {
        let mut body = serde_json::json!({ "content": text });
        if let Some(id) = reply {
            body["message_reference"] = serde_json::json!({ "message_id": id });
        }
        let url = format!("{BASE}/channels/{ch}/messages");
        let mut m: MessageDto = self.json(|| self.http.post(&url).json(&body)).await?;
        m.channel_id = ch.to_string();
        Ok(m)
    }

    pub async fn edit(&self, ch: &str, id: &str, text: &str) -> Result<MessageDto, ApiError> {
        let body = serde_json::json!({ "content": text });
        let url = format!("{BASE}/channels/{ch}/messages/{id}");
        let mut m: MessageDto = self.json(|| self.http.patch(&url).json(&body)).await?;
        m.channel_id = ch.to_string();
        Ok(m)
    }

    pub async fn delete(&self, ch: &str, id: &str) -> Result<(), ApiError> {
        let url = format!("{BASE}/channels/{ch}/messages/{id}");
        self.call(|| self.http.delete(&url)).await?;
        Ok(())
    }

    pub async fn react(&self, ch: &str, id: &str, emoji: &str) -> Result<(), ApiError> {
        let url = format!("{BASE}/channels/{ch}/messages/{id}/reactions/{}/@me", pct(emoji));
        self.call(|| self.http.put(&url).header(header::CONTENT_LENGTH, 0)).await?;
        Ok(())
    }

    /// Downloads a small image. No Authorization header is ever sent here.
    pub async fn fetch(&self, url: &str) -> Option<Vec<u8>> {
        let r = self.img.get(url).send().await.ok()?;
        if !r.status().is_success() {
            return None;
        }
        if r.content_length().map_or(false, |n| n as usize > MAX_IMAGE_BYTES) {
            return None;
        }
        let b = r.bytes().await.ok()?;
        (b.len() <= MAX_IMAGE_BYTES).then(|| b.to_vec())
    }
}

fn pct(s: &str) -> String {
    let mut o = String::new();
    for b in s.bytes() {
        if b.is_ascii_alphanumeric() || matches!(b, b'-' | b'_' | b'.' | b'~') {
            o.push(b as char);
        } else {
            o.push_str(&format!("%{b:02X}"));
        }
    }
    o
}
