fn main() {
    rustcord::run_app();
}
