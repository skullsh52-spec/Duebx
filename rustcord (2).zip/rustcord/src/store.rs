//! Settings (JSON) and message cache (SQLite). Everything is best-effort:
//! a failing cache never breaks the app.
use crate::models::Row;
use rusqlite::{params, Connection};
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};

const KEEP_PER_CHANNEL: i64 = 100;

#[derive(Serialize, Deserialize, Clone)]
#[serde(default)]
pub struct Settings {
    pub token: Option<String>,
    pub bot: bool,
    pub font: u8,
    pub show_time: bool,
    pub images: bool,
}

impl Default for Settings {
    fn default() -> Self {
        Self { token: None, bot: true, font: 1, show_time: true, images: true }
    }
}

impl Settings {
    fn path(dir: &Path) -> PathBuf {
        dir.join("settings.json")
    }

    pub fn load(dir: &Path) -> Self {
        std::fs::read(Self::path(dir))
            .ok()
            .and_then(|b| serde_json::from_slice(&b).ok())
            .unwrap_or_default()
    }

    pub fn save(&self, dir: &Path) {
        let _ = std::fs::create_dir_all(dir);
        let _ = std::fs::write(Self::path(dir), serde_json::to_vec(self).unwrap_or_default());
    }
}

pub struct Cache {
    db: Connection,
}

impl Cache {
    pub fn open(dir: &Path) -> Option<Self> {
        let _ = std::fs::create_dir_all(dir);
        let db = Connection::open(dir.join("cache.db")).ok()?;
        db.execute_batch(
            "PRAGMA cache_size = -512;
             PRAGMA synchronous = NORMAL;
             CREATE TABLE IF NOT EXISTS messages(
                 id INTEGER PRIMARY KEY, ch TEXT NOT NULL,
                 author TEXT, author_id TEXT, raw TEXT, text TEXT,
                 time TEXT, reactions TEXT, reply TEXT, tmin INTEGER, img TEXT);
             CREATE INDEX IF NOT EXISTS messages_ch ON messages(ch, id);",
        )
        .ok()?;
        Some(Self { db })
    }

    pub fn put(&self, ch: &str, r: &Row) {
        if let Ok(id) = r.id.parse::<i64>() {
            let _ = self.db.execute(
                "INSERT OR REPLACE INTO messages
                 (id,ch,author,author_id,raw,text,time,reactions,reply,tmin,img)
                 VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11)",
                params![
                    id, ch, r.author, r.author_id, r.raw, r.text, r.time, r.reactions, r.reply,
                    r.tmin, r.img
                ],
            );
        }
    }

    /// `prune` keeps only the newest messages of the channel.
    pub fn put_many(&self, ch: &str, rows: &[Row], prune: bool) {
        let _ = self.db.execute_batch("BEGIN");
        for r in rows {
            self.put(ch, r);
        }
        if prune {
            let _ = self.db.execute(
                "DELETE FROM messages WHERE ch = ?1 AND id NOT IN
                 (SELECT id FROM messages WHERE ch = ?1 ORDER BY id DESC LIMIT ?2)",
                params![ch, KEEP_PER_CHANNEL],
            );
        }
        let _ = self.db.execute_batch("COMMIT");
    }

    pub fn delete(&self, id: &str) {
        if let Ok(id) = id.parse::<i64>() {
            let _ = self.db.execute("DELETE FROM messages WHERE id = ?1", params![id]);
        }
    }

    /// Newest 50, oldest first.
    pub fn load(&self, ch: &str) -> Vec<Row> {
        let run = || -> rusqlite::Result<Vec<Row>> {
            let mut st = self.db.prepare_cached(
                "SELECT id,author,author_id,raw,text,time,reactions,reply,tmin,img
                 FROM messages WHERE ch = ?1 ORDER BY id DESC LIMIT 50",
            )?;
            let rows = st.query_map([ch], |r| {
                Ok(Row {
                    id: r.get::<_, i64>(0)?.to_string(),
                    author: r.get(1)?,
                    author_id: r.get(2)?,
                    raw: r.get(3)?,
                    text: r.get(4)?,
                    time: r.get(5)?,
                    reactions: r.get(6)?,
                    reply: r.get(7)?,
                    tmin: r.get(8)?,
                    img: r.get(9)?,
                })
            })?;
            let mut v: Vec<Row> = rows.filter_map(Result::ok).collect();
            v.reverse();
            Ok(v)
        };
        run().unwrap_or_default()
    }

    pub fn clear(&self) {
        let _ = self.db.execute("DELETE FROM messages", []);
    }
}
