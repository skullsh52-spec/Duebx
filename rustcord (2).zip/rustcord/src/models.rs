use serde::de::IgnoredAny;
use serde::Deserialize;

#[derive(Deserialize)]
pub struct UserDto {
    pub id: String,
    pub username: String,
    pub global_name: Option<String>,
}

impl UserDto {
    pub fn display(&self) -> &str {
        self.global_name
            .as_deref()
            .filter(|s| !s.is_empty())
            .unwrap_or(&self.username)
    }
}

#[derive(Deserialize)]
pub struct GuildDto {
    pub id: String,
    pub name: String,
}

#[derive(Deserialize)]
pub struct ChannelDto {
    pub id: String,
    pub name: Option<String>,
    #[serde(rename = "type")]
    pub kind: u8,
    #[serde(default)]
    pub position: i32,
    pub parent_id: Option<String>,
}

#[derive(Deserialize)]
pub struct DmDto {
    pub id: String,
    pub name: Option<String>,
    #[serde(default)]
    pub recipients: Vec<UserDto>,
    pub last_message_id: Option<String>,
}

#[derive(Deserialize)]
pub struct AttachmentDto {
    pub filename: String,
    pub content_type: Option<String>,
    pub url: Option<String>,
    pub proxy_url: Option<String>,
}

#[derive(Deserialize)]
pub struct EmojiDto {
    pub name: Option<String>,
}

#[derive(Deserialize)]
pub struct ReactionDto {
    pub count: u32,
    pub emoji: EmojiDto,
}

#[derive(Deserialize)]
pub struct RefDto {
    #[serde(default)]
    pub content: String,
    pub author: Option<UserDto>,
}

#[derive(Deserialize)]
pub struct MessageDto {
    pub id: String,
    #[serde(default)]
    pub channel_id: String,
    #[serde(default)]
    pub content: String,
    pub author: UserDto,
    #[serde(default)]
    pub timestamp: String,
    #[serde(default)]
    pub mentions: Vec<UserDto>,
    #[serde(default)]
    pub attachments: Vec<AttachmentDto>,
    #[serde(default)]
    pub embeds: Vec<IgnoredAny>,
    #[serde(default)]
    pub reactions: Vec<ReactionDto>,
    pub referenced_message: Option<Box<RefDto>>,
}

#[derive(Deserialize)]
pub struct DelDto {
    pub id: String,
    pub channel_id: String,
}

/// Plain, display-ready message (Send-safe). The cache stores this.
#[derive(Clone)]
pub struct Row {
    pub id: String,
    pub author: String,
    pub author_id: String,
    pub raw: String,
    pub text: String,
    pub time: String,
    pub reactions: String,
    pub reply: String,
    pub tmin: i64,
    pub img: String,
}

fn short_time(ts: &str) -> String {
    match (ts.get(5..10), ts.get(11..16)) {
        (Some(d), Some(t)) => format!("{d} {t} UTC"),
        _ => String::new(),
    }
}

fn days_from_civil(y: i64, m: i64, d: i64) -> i64 {
    let y = if m <= 2 { y - 1 } else { y };
    let era = y.div_euclid(400);
    let yoe = y - era * 400;
    let mp = (m + 9) % 12;
    let doy = (153 * mp + 2) / 5 + d - 1;
    let doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    era * 146097 + doe - 719468
}

/// Minutes since the Unix epoch from an ISO timestamp, 0 if it can't be parsed.
fn unix_min(ts: &str) -> i64 {
    let parse = || -> Option<i64> {
        let y: i64 = ts.get(0..4)?.parse().ok()?;
        let mo: i64 = ts.get(5..7)?.parse().ok()?;
        let d: i64 = ts.get(8..10)?.parse().ok()?;
        let h: i64 = ts.get(11..13)?.parse().ok()?;
        let mi: i64 = ts.get(14..16)?.parse().ok()?;
        Some(days_from_civil(y, mo, d) * 1440 + h * 60 + mi)
    };
    parse().unwrap_or(0)
}

fn token(inner: &str, mentions: &[UserDto]) -> Option<String> {
    if inner.starts_with("@&") {
        return Some("@role".into());
    }
    if let Some(id) = inner.strip_prefix("@!").or_else(|| inner.strip_prefix('@')) {
        return Some(match mentions.iter().find(|u| u.id == id) {
            Some(u) => format!("@{}", u.display()),
            None => "@user".into(),
        });
    }
    if inner.starts_with('#') {
        return Some("#channel".into());
    }
    let e = inner.strip_prefix("a:").or_else(|| inner.strip_prefix(':'))?;
    let name = e.split(':').next()?;
    if name.is_empty() {
        return None;
    }
    Some(format!(":{name}:"))
}

/// Turns <@id>, <#id>, <@&id>, <:emoji:id> into readable text.
fn clean(content: &str, mentions: &[UserDto]) -> String {
    if !content.contains('<') {
        return content.to_string();
    }
    let mut out = String::with_capacity(content.len());
    let mut rest = content;
    while let Some(i) = rest.find('<') {
        out.push_str(&rest[..i]);
        let tail = &rest[i..];
        match tail.find('>') {
            Some(j) if j <= 64 => {
                match token(&tail[1..j], mentions) {
                    Some(t) => out.push_str(&t),
                    None => out.push_str(&tail[..=j]),
                }
                rest = &tail[j + 1..];
            }
            _ => {
                out.push('<');
                rest = &tail[1..];
            }
        }
    }
    out.push_str(rest);
    out
}

fn is_image(a: &AttachmentDto) -> bool {
    match a.content_type.as_deref() {
        Some(t) => t.starts_with("image/"),
        None => {
            let f = a.filename.to_ascii_lowercase();
            [".png", ".jpg", ".jpeg", ".webp", ".gif"].iter().any(|e| f.ends_with(e))
        }
    }
}

impl Row {
    pub fn from_dto(m: &MessageDto) -> Row {
        let mut text = clean(&m.content, &m.mentions);
        for a in &m.attachments {
            if !text.is_empty() {
                text.push('\n');
            }
            text.push_str(if is_image(a) { "[image] " } else { "[file] " });
            text.push_str(&a.filename);
        }
        if text.is_empty() && !m.embeds.is_empty() {
            text.push_str("[embed]");
        }
        let reactions = m
            .reactions
            .iter()
            .map(|r| format!("{} {}", r.emoji.name.as_deref().unwrap_or("?"), r.count))
            .collect::<Vec<_>>()
            .join("   ");
        let reply = match &m.referenced_message {
            Some(r) => {
                let who = r.author.as_ref().map(|u| u.display()).unwrap_or("unknown");
                let snippet: String = clean(&r.content, &[]).chars().take(60).collect();
                format!("> {who}: {snippet}")
            }
            None => String::new(),
        };
        // small resized preview of the first image attachment
        let img = m
            .attachments
            .iter()
            .find(|a| is_image(a))
            .and_then(|a| a.proxy_url.as_deref().or(a.url.as_deref()))
            .map(|b| {
                let sep = if b.contains('?') { '&' } else { '?' };
                format!("{b}{sep}format=webp&width=320&height=320")
            })
            .unwrap_or_default();
        Row {
            id: m.id.clone(),
            author: m.author.display().to_string(),
            author_id: m.author.id.clone(),
            raw: m.content.clone(),
            text,
            time: short_time(&m.timestamp),
            reactions,
            reply,
            tmin: unix_min(&m.timestamp),
            img,
        }
    }
}
