mod api;
mod gateway;
mod models;
mod store;

use api::Api;
use models::{ChannelDto, MessageDto, Row};
use slint::{ComponentHandle, Image, Model, ModelRc, Rgba8Pixel, SharedPixelBuffer, VecModel, Weak};
use std::collections::VecDeque;
use std::path::PathBuf;
use std::sync::{Arc, Mutex, OnceLock};
use store::{Cache, Settings};
use tokio::sync::mpsc::{unbounded_channel, UnboundedSender};

slint::include_modules!();

const MAX_ROWS: usize = 300; // messages kept in the UI when new ones arrive
const SEEN_CAP: usize = 256; // ids remembered for de-duplication
const FONTS: [f32; 3] = [14.0, 16.0, 19.0];
const MAX_PREVIEWS: usize = 6; // image previews fetched per channel open
const GROUP_MINUTES: i64 = 7; // consecutive messages by one author are grouped

static DATA_DIR: OnceLock<PathBuf> = OnceLock::new();

fn data_dir() -> PathBuf {
    DATA_DIR
        .get_or_init(|| {
            std::env::var_os("HOME")
                .or_else(|| std::env::var_os("APPDATA"))
                .map(PathBuf::from)
                .unwrap_or_else(|| PathBuf::from("."))
                .join(".rustcord")
        })
        .clone()
}

pub enum Cmd {
    Login { token: String, bot: bool },
    Logout,
    OpenGuild(String, String),
    OpenChannel { id: String, name: String, dm: bool },
    OpenDms,
    Refresh,
    LoadOlder,
    Send { text: String, reply: String },
    Edit { id: String, text: String },
    Delete(String),
    React { id: String, emoji: String },
    SaveFont(u8),
    SaveTime(bool),
    SaveImages(bool),
    ClearCache,
    Image { channel: String, id: String, buf: SharedPixelBuffer<Rgba8Pixel> },
    GwCreate(MessageDto),
    GwUpdate(MessageDto),
    GwDelete { channel: String, id: String },
    Status(String),
}

// ---------- UI-thread helpers (Msg holds an Image, so it is built on the UI thread) ----------

fn to_msg(r: &Row, me: &str, prev: Option<&Row>) -> Msg {
    let compact = prev.map_or(false, |p| {
        p.author_id == r.author_id
            && r.reply.is_empty()
            && r.tmin > 0
            && (0..=GROUP_MINUTES).contains(&(r.tmin - p.tmin))
    });
    Msg {
        id: r.id.clone().into(),
        author: r.author.clone().into(),
        author_id: r.author_id.clone().into(),
        text: r.text.clone().into(),
        raw: r.raw.clone().into(),
        time: r.time.clone().into(),
        reactions: r.reactions.clone().into(),
        reply: r.reply.clone().into(),
        mine: !me.is_empty() && r.author_id == me,
        compact,
        tmin: r.tmin as i32,
        has_image: false,
        image: Image::default(),
    }
}

fn build_model(rows: &[Row], me: &str) -> ModelRc<Msg> {
    let v: Vec<Msg> = rows
        .iter()
        .enumerate()
        .map(|(i, r)| to_msg(r, me, i.checked_sub(1).map(|j| &rows[j])))
        .collect();
    ModelRc::new(VecModel::from(v))
}

fn with_vm(app: &App, f: impl FnOnce(&VecModel<Msg>)) {
    let model = app.get_messages();
    if let Some(vm) = model.as_any().downcast_ref::<VecModel<Msg>>() {
        f(vm);
    }
}

fn push_row(app: &App, r: &Row, me: &str) {
    with_vm(app, |vm| {
        let mut m = to_msg(r, me, None);
        if let Some(last) = vm.row_count().checked_sub(1).and_then(|i| vm.row_data(i)) {
            let dt = (m.tmin - last.tmin) as i64;
            m.compact = last.author_id == m.author_id
                && m.reply.is_empty()
                && m.tmin > 0
                && (0..=GROUP_MINUTES).contains(&dt);
        }
        vm.push(m);
        while vm.row_count() > MAX_ROWS {
            vm.remove(0);
        }
    });
}

fn replace_row(app: &App, r: &Row, me: &str) {
    with_vm(app, |vm| {
        if let Some(i) = vm.iter().position(|x| x.id.as_str() == r.id) {
            if let Some(old) = vm.row_data(i) {
                let mut m = to_msg(r, me, None);
                m.compact = old.compact;
                m.has_image = old.has_image;
                m.image = old.image.clone();
                vm.set_row_data(i, m);
            }
        }
    });
}

fn prepend_rows(app: &App, rows: &[Row], me: &str) {
    with_vm(app, |vm| {
        for (k, r) in rows.iter().enumerate() {
            vm.insert(k, to_msg(r, me, k.checked_sub(1).map(|j| &rows[j])));
        }
    });
}

fn remove_row(app: &App, id: &str) {
    with_vm(app, |vm| {
        if let Some(i) = vm.iter().position(|x| x.id.as_str() == id) {
            vm.remove(i);
        }
    });
}

fn set_image(app: &App, id: &str, buf: SharedPixelBuffer<Rgba8Pixel>) {
    with_vm(app, |vm| {
        if let Some(i) = vm.iter().position(|x| x.id.as_str() == id) {
            if let Some(mut m) = vm.row_data(i) {
                m.image = Image::from_rgba8(buf);
                m.has_image = true;
                vm.set_row_data(i, m);
            }
        }
    });
}

/// Runs on a blocking thread. Output is at most 320px on a side.
fn decode(bytes: &[u8]) -> Option<SharedPixelBuffer<Rgba8Pixel>> {
    let mut img = image::load_from_memory(bytes).ok()?;
    if img.width() > 320 || img.height() > 320 {
        img = img.thumbnail(320, 320);
    }
    let rgba = img.to_rgba8();
    Some(SharedPixelBuffer::<Rgba8Pixel>::clone_from_slice(
        rgba.as_raw(),
        rgba.width(),
        rgba.height(),
    ))
}

fn channel_items(cs: &[ChannelDto]) -> Vec<Item> {
    fn children(cs: &[ChannelDto], parent: Option<&str>, out: &mut Vec<Item>) {
        let mut list: Vec<&ChannelDto> = cs
            .iter()
            .filter(|c| matches!(c.kind, 0 | 5) && c.parent_id.as_deref() == parent)
            .collect();
        list.sort_by_key(|c| c.position);
        for c in list {
            out.push(Item {
                id: c.id.clone().into(),
                name: c.name.clone().unwrap_or_default().into(),
                header: false,
            });
        }
    }
    let mut out = Vec::new();
    children(cs, None, &mut out); // channels without a category come first
    let mut cats: Vec<&ChannelDto> = cs.iter().filter(|c| c.kind == 4).collect();
    cats.sort_by_key(|c| c.position);
    for cat in cats {
        let at = out.len();
        out.push(Item {
            id: "".into(),
            name: cat.name.clone().unwrap_or_default().to_uppercase().into(),
            header: true,
        });
        children(cs, Some(&cat.id), &mut out);
        if out.len() == at + 1 {
            out.pop(); // empty category
        }
    }
    out
}

// ---------- background worker ----------

struct Worker {
    ui: Weak<App>,
    tx: UnboundedSender<Cmd>,
    dir: PathBuf,
    settings: Settings,
    cache: Option<Cache>,
    current: Arc<Mutex<String>>,
    title: String,
    oldest: Option<String>,
    api: Option<Api>,
    me: String,
    gw: Option<tokio::task::JoinHandle<()>>,
    seen: VecDeque<String>,
}

impl Worker {
    fn ui(&self, f: impl FnOnce(App) + Send + 'static) {
        let _ = self.ui.upgrade_in_event_loop(f);
    }

    fn status(&self, s: impl Into<String>) {
        let s: String = s.into();
        self.ui(move |a| a.set_status(s.into()));
    }

    fn is_current(&self, ch: &str) -> bool {
        *self.current.lock().unwrap() == ch
    }

    fn current_channel(&self) -> String {
        self.current.lock().unwrap().clone()
    }

    fn mark(&mut self, id: &str) -> bool {
        if self.seen.iter().any(|s| s == id) {
            return false;
        }
        if self.seen.len() >= SEEN_CAP {
            self.seen.pop_front();
        }
        self.seen.push_back(id.to_owned());
        true
    }

    async fn handle(&mut self, cmd: Cmd) {
        match cmd {
            Cmd::Login { token, bot } => self.login(token, bot).await,
            Cmd::Logout => self.logout(),
            Cmd::OpenGuild(id, name) => self.open_guild(id, name).await,
            Cmd::OpenChannel { id, name, dm } => {
                let title = if dm { format!("@{name}") } else { format!("#{name}") };
                self.open_channel(id, title).await
            }
            Cmd::OpenDms => self.open_dms().await,
            Cmd::Refresh => {
                let id = self.current_channel();
                if !id.is_empty() {
                    let title = self.title.clone();
                    self.open_channel(id, title).await;
                }
            }
            Cmd::LoadOlder => self.load_older().await,
            Cmd::Send { text, reply } => self.send(text, reply).await,
            Cmd::Edit { id, text } => self.edit(id, text).await,
            Cmd::Delete(id) => self.delete(id).await,
            Cmd::React { id, emoji } => self.react(id, emoji).await,
            Cmd::SaveFont(f) => {
                self.settings.font = f;
                self.settings.save(&self.dir);
            }
            Cmd::SaveTime(v) => {
                self.settings.show_time = v;
                self.settings.save(&self.dir);
            }
            Cmd::SaveImages(v) => {
                self.settings.images = v;
                self.settings.save(&self.dir);
            }
            Cmd::ClearCache => {
                if let Some(c) = &self.cache {
                    c.clear();
                }
                self.status("Cache cleared");
            }
            Cmd::Image { channel, id, buf } => {
                if self.is_current(&channel) {
                    self.ui(move |a| set_image(&a, &id, buf));
                }
            }
            Cmd::GwCreate(m) => self.on_create(m),
            Cmd::GwUpdate(m) => self.on_update(m),
            Cmd::GwDelete { channel, id } => self.on_delete(&channel, id),
            Cmd::Status(s) => self.status(s),
        }
    }

    // ---- images ----

    fn spawn_image(&self, ch: &str, id: &str, url: &str) {
        if !self.settings.images || url.is_empty() {
            return;
        }
        let Some(api) = self.api.clone() else { return };
        let tx = self.tx.clone();
        let (channel, id, url) = (ch.to_string(), id.to_string(), url.to_string());
        tokio::spawn(async move {
            let Some(bytes) = api.fetch(&url).await else { return };
            let buf = tokio::task::spawn_blocking(move || decode(&bytes)).await.ok().flatten();
            if let Some(buf) = buf {
                let _ = tx.send(Cmd::Image { channel, id, buf });
            }
        });
    }

    fn spawn_images(&self, ch: &str, rows: &[Row]) {
        for r in rows.iter().rev().filter(|r| !r.img.is_empty()).take(MAX_PREVIEWS) {
            self.spawn_image(ch, &r.id, &r.img);
        }
    }

    // ---- session ----

    async fn login(&mut self, token: String, bot: bool) {
        let token = token.trim().to_string();
        if token.is_empty() {
            return self.status("Enter a token");
        }
        self.status("Logging in…");
        let api = match Api::new(&token, bot) {
            Ok(a) => a,
            Err(e) => return self.status(e),
        };
        let me = match api.me().await {
            Ok(u) => u,
            Err(e) => {
                if e.code == 401 {
                    self.settings.token = None; // saved token is no longer valid
                    self.settings.save(&self.dir);
                }
                return self.status(format!("Login failed: {e}"));
            }
        };
        let guilds = match api.guilds().await {
            Ok(g) => g,
            Err(e) => return self.status(format!("Couldn't load servers: {e}")),
        };
        self.me = me.id;
        self.settings.token = Some(token.clone());
        self.settings.bot = bot;
        self.settings.save(&self.dir);

        let items: Vec<Item> = guilds
            .into_iter()
            .map(|g| Item { id: g.id.into(), name: g.name.into(), header: false })
            .collect();
        self.ui(move |a| {
            a.set_guilds(ModelRc::new(VecModel::from(items)));
            a.set_status("".into());
            a.set_page(1);
        });
        if let Some(h) = self.gw.take() {
            h.abort();
        }
        self.gw = Some(tokio::spawn(gateway::run(
            token,
            bot,
            self.tx.clone(),
            self.current.clone(),
        )));
        self.api = Some(api);
    }

    fn logout(&mut self) {
        if let Some(h) = self.gw.take() {
            h.abort();
        }
        self.api = None;
        self.me.clear();
        self.current.lock().unwrap().clear();
        self.seen.clear();
        self.oldest = None;
        self.settings.token = None;
        self.settings.save(&self.dir);
        if let Some(c) = &self.cache {
            c.clear();
        }
        self.ui(|a| {
            a.set_guilds(ModelRc::default());
            a.set_channels(ModelRc::default());
            a.set_dms(ModelRc::default());
            a.set_messages(ModelRc::default());
            a.set_status("".into());
            a.set_page(0);
        });
    }

    // ---- navigation ----

    async fn open_guild(&mut self, id: String, name: String) {
        let Some(api) = self.api.clone() else { return };
        match api.channels(&id).await {
            Ok(cs) => {
                let items = channel_items(&cs);
                self.ui(move |a| {
                    a.set_channels(ModelRc::new(VecModel::from(items)));
                    a.set_heading(name.into());
                    a.set_status("".into());
                    a.set_page(2);
                });
            }
            Err(e) => self.status(format!("Couldn't load channels: {e}")),
        }
    }

    async fn open_dms(&mut self) {
        let Some(api) = self.api.clone() else { return };
        match api.dms().await {
            Ok(mut ds) => {
                let key = |d: &models::DmDto| {
                    d.last_message_id.as_deref().and_then(|s| s.parse::<u64>().ok())
                };
                ds.sort_by(|a, b| key(b).cmp(&key(a))); // most recent first
                let items: Vec<Item> = ds
                    .into_iter()
                    .map(|d| {
                        let name = match d.name.filter(|n| !n.is_empty()) {
                            Some(n) => n,
                            None => d
                                .recipients
                                .iter()
                                .map(|u| u.display())
                                .collect::<Vec<_>>()
                                .join(", "),
                        };
                        Item { id: d.id.into(), name: name.into(), header: false }
                    })
                    .collect();
                self.ui(move |a| {
                    a.set_dms(ModelRc::new(VecModel::from(items)));
                    a.set_status("".into());
                });
            }
            Err(e) => self.status(format!("Couldn't load DMs (bots can't list them): {e}")),
        }
    }

    async fn open_channel(&mut self, id: String, title: String) {
        let Some(api) = self.api.clone() else { return };
        *self.current.lock().unwrap() = id.clone();
        self.title = title.clone();
        self.seen.clear();

        // 1) show cached messages instantly
        let cached = self.cache.as_ref().map(|c| c.load(&id)).unwrap_or_default();
        for r in &cached {
            self.mark(&r.id);
        }
        self.oldest = cached.first().map(|r| r.id.clone());
        let me = self.me.clone();
        self.ui(move |a| {
            a.set_messages(build_model(&cached, &me));
            a.set_chat_heading(title.into());
            a.set_follow(true);
            a.set_status("".into());
            a.set_page(3);
        });

        // 2) refresh from the network
        match api.messages(&id).await {
            Ok(mut ms) => {
                ms.reverse(); // oldest first
                let fresh: Vec<Row> = ms.iter().map(Row::from_dto).collect();
                if let Some(c) = &self.cache {
                    c.put_many(&id, &fresh, true);
                }
                self.seen.clear();
                for r in &fresh {
                    self.mark(&r.id);
                }
                self.oldest = fresh.first().map(|r| r.id.clone());
                self.spawn_images(&id, &fresh);
                let me = self.me.clone();
                self.ui(move |a| {
                    a.set_follow(true);
                    a.set_messages(build_model(&fresh, &me));
                });
            }
            Err(e) => self.status(format!("Couldn't refresh messages: {e}")),
        }
    }

    async fn load_older(&mut self) {
        let Some(api) = self.api.clone() else { return };
        let ch = self.current_channel();
        let Some(before) = self.oldest.clone() else {
            return self.status("No older messages");
        };
        match api.messages_before(&ch, &before).await {
            Ok(mut ms) => {
                if ms.is_empty() {
                    return self.status("No older messages");
                }
                ms.reverse();
                let rows: Vec<Row> = ms.iter().map(Row::from_dto).collect();
                if let Some(c) = &self.cache {
                    c.put_many(&ch, &rows, false);
                }
                self.oldest = rows.first().map(|r| r.id.clone());
                for r in &rows {
                    self.mark(&r.id);
                }
                self.spawn_images(&ch, &rows);
                let me = self.me.clone();
                self.ui(move |a| {
                    a.set_follow(false); // stay at the top, don't jump to the bottom
                    prepend_rows(&a, &rows, &me);
                });
            }
            Err(e) => self.status(format!("Couldn't load older messages: {e}")),
        }
    }

    // ---- message actions ----

    async fn send(&mut self, text: String, reply: String) {
        let Some(api) = self.api.clone() else { return };
        let ch = self.current_channel();
        if ch.is_empty() {
            return;
        }
        let reply_ref = (!reply.is_empty()).then_some(reply.as_str());
        match api.send(&ch, &text, reply_ref).await {
            Ok(m) => {
                self.ui(|a| a.set_follow(true));
                self.on_create(m);
            }
            Err(e) => self.status(format!("Send failed: {e}")),
        }
    }

    async fn edit(&mut self, id: String, text: String) {
        let Some(api) = self.api.clone() else { return };
        let ch = self.current_channel();
        match api.edit(&ch, &id, &text).await {
            Ok(m) => self.on_update(m),
            Err(e) => self.status(format!("Edit failed: {e}")),
        }
    }

    async fn delete(&mut self, id: String) {
        let Some(api) = self.api.clone() else { return };
        let ch = self.current_channel();
        match api.delete(&ch, &id).await {
            Ok(()) => self.on_delete(&ch, id),
            Err(e) => self.status(format!("Delete failed: {e}")),
        }
    }

    async fn react(&mut self, id: String, emoji: String) {
        let Some(api) = self.api.clone() else { return };
        let ch = self.current_channel();
        if let Err(e) = api.react(&ch, &id, &emoji).await {
            return self.status(format!("Reaction failed: {e}"));
        }
        if let Ok(m) = api.message(&ch, &id).await {
            self.on_update(m);
        }
    }

    // ---- applying message changes (from REST or gateway) ----

    fn on_create(&mut self, m: MessageDto) {
        if !self.is_current(&m.channel_id) {
            return;
        }
        let row = Row::from_dto(&m);
        if let Some(c) = &self.cache {
            c.put(&m.channel_id, &row);
        }
        if !self.mark(&row.id) {
            return;
        }
        self.spawn_image(&m.channel_id, &row.id, &row.img);
        let me = self.me.clone();
        self.ui(move |a| push_row(&a, &row, &me));
    }

    fn on_update(&mut self, m: MessageDto) {
        if !self.is_current(&m.channel_id) {
            return;
        }
        let row = Row::from_dto(&m);
        if let Some(c) = &self.cache {
            c.put(&m.channel_id, &row);
        }
        let me = self.me.clone();
        self.ui(move |a| replace_row(&a, &row, &me));
    }

    fn on_delete(&mut self, ch: &str, id: String) {
        if let Some(c) = &self.cache {
            c.delete(&id);
        }
        if self.is_current(ch) {
            self.ui(move |a| remove_row(&a, &id));
        }
    }
}

pub fn run_app() {
    let _ = rustls::crypto::ring::default_provider().install_default();

    let dir = data_dir();
    let _ = std::fs::create_dir_all(&dir);
    let settings = Settings::load(&dir);

    let app = App::new().unwrap();
    {
        let theme = app.global::<Theme>();
        #[cfg(not(target_os = "android"))]
        {
            theme.set_top_inset(0.0);
            theme.set_bottom_inset(0.0);
        }
        let idx = settings.font.min(2) as usize;
        theme.set_msg_font(FONTS[idx]);
        theme.set_show_time(settings.show_time);
        theme.set_images(settings.images);
        app.set_font_idx(idx as i32);
    }

    let (tx, mut rx) = unbounded_channel::<Cmd>();

    // One background thread, one single-threaded async runtime.
    {
        let ui = app.as_weak();
        let tx = tx.clone();
        let dir = dir.clone();
        let settings = settings.clone();
        std::thread::spawn(move || {
            let rt = tokio::runtime::Builder::new_current_thread()
                .enable_all()
                .build()
                .unwrap();
            rt.block_on(async move {
                let cache = Cache::open(&dir);
                let mut w = Worker {
                    ui,
                    tx,
                    dir,
                    settings,
                    cache,
                    current: Arc::default(),
                    title: String::new(),
                    oldest: None,
                    api: None,
                    me: String::new(),
                    gw: None,
                    seen: VecDeque::new(),
                };
                while let Some(cmd) = rx.recv().await {
                    w.handle(cmd).await;
                }
            });
        });
    }

    macro_rules! wire {
        ($on:ident, |$($a:ident),*| $cmd:expr) => {{
            let t = tx.clone();
            app.$on(move |$($a),*| {
                let _ = t.send($cmd);
            });
        }};
    }

    wire!(on_login, |token, bot| Cmd::Login { token: token.to_string(), bot });
    wire!(on_logout, | | Cmd::Logout);
    wire!(on_load_dms, | | Cmd::OpenDms);
    wire!(on_refresh, | | Cmd::Refresh);
    wire!(on_load_older, | | Cmd::LoadOlder);
    wire!(on_open_guild, |id, name| Cmd::OpenGuild(id.to_string(), name.to_string()));
    wire!(on_open_channel, |id, name| Cmd::OpenChannel {
        id: id.to_string(),
        name: name.to_string(),
        dm: false
    });
    wire!(on_open_dm, |id, name| Cmd::OpenChannel {
        id: id.to_string(),
        name: name.to_string(),
        dm: true
    });
    wire!(on_send_msg, |text, reply| Cmd::Send { text: text.to_string(), reply: reply.to_string() });
    wire!(on_edit_msg, |id, text| Cmd::Edit { id: id.to_string(), text: text.to_string() });
    wire!(on_remove_msg, |id| Cmd::Delete(id.to_string()));
    wire!(on_react_msg, |id, emoji| Cmd::React { id: id.to_string(), emoji: emoji.to_string() });
    wire!(on_save_font, |i| Cmd::SaveFont(i.clamp(0, 2) as u8));
    wire!(on_save_time, |v| Cmd::SaveTime(v));
    wire!(on_save_images, |v| Cmd::SaveImages(v));
    wire!(on_clear_cache, | | Cmd::ClearCache);

    // stay logged in
    if let Some(token) = settings.token.clone() {
        let _ = tx.send(Cmd::Login { token, bot: settings.bot });
    }

    app.run().unwrap();
}

#[cfg(target_os = "android")]
#[no_mangle]
fn android_main(app: slint::android::AndroidApp) {
    if let Some(p) = app.internal_data_path() {
        let _ = DATA_DIR.set(p);
    }
    slint::android::init(app).unwrap();
    run_app();
}
