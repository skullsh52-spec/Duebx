//! Discord gateway with resume support. Frames are parsed with borrowed
//! `RawValue`s, so the huge READY payload and every event we don't care about
//! are skipped without building a JSON tree. Only events for the open channel
//! are fully parsed.
use crate::models::{DelDto, MessageDto};
use crate::Cmd;
use futures_util::{SinkExt, StreamExt};
use serde::Deserialize;
use serde_json::{json, value::RawValue};
use std::{
    sync::{Arc, Mutex},
    time::Duration,
};
use tokio::sync::mpsc::UnboundedSender;
use tokio::time::{interval_at, sleep, Instant};
use tokio_tungstenite::{connect_async, tungstenite::Message};

const URL: &str = "wss://gateway.discord.gg/?v=10&encoding=json";
// GUILDS | GUILD_MESSAGES | DIRECT_MESSAGES | MESSAGE_CONTENT (privileged: enable in dev portal)
const INTENTS: u64 = (1 << 0) | (1 << 9) | (1 << 12) | (1 << 15);

type DynErr = Box<dyn std::error::Error + Send + Sync>;

#[derive(Deserialize)]
struct Frame<'a> {
    op: u8,
    s: Option<u64>,
    #[serde(borrow)]
    t: Option<&'a str>,
    #[serde(borrow)]
    d: Option<&'a RawValue>,
}

#[derive(Deserialize)]
struct Hello {
    heartbeat_interval: u64,
}

#[derive(Deserialize)]
struct Ready {
    session_id: String,
    resume_gateway_url: String,
}

#[derive(Deserialize)]
struct Peek<'a> {
    channel_id: &'a str,
}

enum Outcome {
    Ready,
    Dropped,
    Fatal,
}

fn is_current(current: &Mutex<String>, id: &str) -> bool {
    *current.lock().unwrap() == id
}

pub async fn run(
    token: String,
    bot: bool,
    tx: UnboundedSender<Cmd>,
    current: Arc<Mutex<String>>,
) {
    // (session_id, resume_url) and last sequence number, kept across reconnects
    let mut resume: Option<(String, String)> = None;
    let mut seq: Option<u64> = None;
    let mut backoff = 2u64;
    loop {
        match session(&token, bot, &tx, &current, &mut resume, &mut seq).await {
            Ok(Outcome::Fatal) => return,
            Ok(Outcome::Ready) => backoff = 2,
            _ => {}
        }
        let _ = tx.send(Cmd::Status("Disconnected, reconnecting…".into()));
        sleep(Duration::from_secs(backoff)).await;
        backoff = (backoff * 2).min(30);
    }
}

async fn session(
    token: &str,
    bot: bool,
    tx: &UnboundedSender<Cmd>,
    current: &Mutex<String>,
    resume: &mut Option<(String, String)>,
    seq: &mut Option<u64>,
) -> Result<Outcome, DynErr> {
    let url = match &*resume {
        Some((_, u)) => format!("{u}/?v=10&encoding=json"),
        None => URL.to_string(),
    };
    let (ws, _) = connect_async(url.as_str()).await?;
    let (mut sink, mut stream) = ws.split();

    let hello_text = loop {
        match stream.next().await {
            Some(Ok(Message::Text(t))) => break t,
            Some(Ok(_)) => continue,
            _ => return Ok(Outcome::Dropped),
        }
    };
    let frame: Frame = serde_json::from_str(&hello_text)?;
    let hello: Hello = serde_json::from_str(frame.d.ok_or("no hello data")?.get())?;
    let period = Duration::from_millis(hello.heartbeat_interval);

    let first = match &*resume {
        Some((sid, _)) => json!({ "op": 6, "d": { "token": token, "session_id": sid, "seq": *seq } }),
        None => {
            *seq = None;
            let mut identify = json!({
                "op": 2,
                "d": { "token": token, "properties": { "os": "android", "browser": "rustcord", "device": "rustcord" } }
            });
            if bot {
                identify["d"]["intents"] = json!(INTENTS);
            }
            identify
        }
    };
    sink.send(Message::Text(first.to_string())).await?;

    let mut beat = interval_at(Instant::now() + period, period);
    let mut ready = false;

    loop {
        tokio::select! {
            _ = beat.tick() => {
                sink.send(Message::Text(json!({"op": 1, "d": *seq}).to_string())).await?;
            }
            msg = stream.next() => {
                let Some(msg) = msg else { return Ok(Outcome::Dropped) };
                let text = match msg? {
                    Message::Text(t) => t,
                    Message::Close(frame) => {
                        if let Some(cf) = frame {
                            let code: u16 = cf.code.into();
                            if matches!(code, 4007 | 4009) {
                                *resume = None;
                                *seq = None;
                            }
                            let note = match code {
                                4004 => Some("Gateway: invalid token"),
                                4013 | 4014 => Some("Gateway: intents not allowed. Enable Message Content Intent in the developer portal"),
                                4010 | 4011 | 4012 => Some("Gateway: connection refused"),
                                _ => None,
                            };
                            if let Some(n) = note {
                                let _ = tx.send(Cmd::Status(n.into()));
                                return Ok(Outcome::Fatal);
                            }
                        }
                        return Ok(if ready { Outcome::Ready } else { Outcome::Dropped });
                    }
                    _ => continue,
                };
                let Ok(f) = serde_json::from_str::<Frame>(&text) else { continue };
                if f.s.is_some() { *seq = f.s; }
                match f.op {
                    0 => match f.t {
                        Some("READY") => {
                            if let Some(d) = f.d {
                                if let Ok(r) = serde_json::from_str::<Ready>(d.get()) {
                                    *resume = Some((r.session_id, r.resume_gateway_url));
                                }
                            }
                            ready = true;
                            let _ = tx.send(Cmd::Status(String::new()));
                        }
                        Some("RESUMED") => {
                            ready = true;
                            let _ = tx.send(Cmd::Status(String::new()));
                        }
                        Some(ev @ ("MESSAGE_CREATE" | "MESSAGE_UPDATE" | "MESSAGE_DELETE")) => {
                            let Some(d) = f.d else { continue };
                            let wanted = serde_json::from_str::<Peek>(d.get())
                                .map(|p| is_current(current, p.channel_id))
                                .unwrap_or(false);
                            if !wanted { continue; }
                            match ev {
                                "MESSAGE_CREATE" => {
                                    if let Ok(m) = serde_json::from_str::<MessageDto>(d.get()) {
                                        let _ = tx.send(Cmd::GwCreate(m));
                                    }
                                }
                                "MESSAGE_UPDATE" => {
                                    // partial updates (no author) fail to parse and are skipped
                                    if let Ok(m) = serde_json::from_str::<MessageDto>(d.get()) {
                                        let _ = tx.send(Cmd::GwUpdate(m));
                                    }
                                }
                                _ => {
                                    if let Ok(x) = serde_json::from_str::<DelDto>(d.get()) {
                                        let _ = tx.send(Cmd::GwDelete { channel: x.channel_id, id: x.id });
                                    }
                                }
                            }
                        }
                        _ => {}
                    },
                    1 => sink.send(Message::Text(json!({"op": 1, "d": *seq}).to_string())).await?,
                    7 => return Ok(Outcome::Dropped), // server asked us to reconnect (resume)
                    9 => {
                        // invalid session; d == true means it can be resumed
                        let resumable = f.d.map_or(false, |d| d.get().trim() == "true");
                        if !resumable {
                            *resume = None;
                            *seq = None;
                        }
                        return Ok(Outcome::Dropped);
                    }
                    _ => {}
                }
            }
        }
    }
}
