# Rustcord 0.3

A small, fast Discord mobile client in Rust (Slint UI, tokio, rustls, SQLite).
Text first, with small optional image previews, to keep memory low.

## Features
- Login with a bot token (or user token, see below); saved between launches
- Servers -> text channels grouped by category, plus a Direct Messages list
- Live chat over the gateway: new, edited and deleted messages
- Gateway RESUME: short disconnects replay missed events instead of starting over
- Send, reply, edit and delete your own messages, add reactions (tap a message)
- Readable mentions (@name, #channel, :emoji:) and grouped consecutive messages
- "Load older messages" paging, manual Refresh
- Image previews: first image of a message, resized to 320px, max 6 per open,
  2 MB cap, downloaded without credentials. Can be switched off in Settings.
- SQLite cache: opening a channel shows cached messages instantly, then refreshes
- Rate-limit handling (retries on 429) and clear error messages
- Settings: text size, timestamps, image previews, clear cache, log out

## Why it is light
- Slint native UI, no webview, no JS runtime
- `ListView` only builds the rows on screen
- One network thread with a single-threaded tokio runtime
- Gateway frames are parsed as borrowed raw JSON: READY and events for other
  channels are never turned into JSON trees
- 50 messages per load, 300 kept in the UI, 100 per channel in the cache
- Release profile: LTO, 1 codegen unit, panic=abort, stripped

## Project layout
    ui/               theme, components, login, chat, settings, app shell (.slint)
    src/api.rs        REST calls, retry, error mapping, image download
    src/gateway.rs    websocket gateway with resume
    src/models.rs     JSON types, text cleanup, display rows
    src/store.rs      settings file + SQLite cache
    src/lib.rs        worker, state, wiring, Android entry

## Run on desktop
    cargo run --release

## Build the Android APK
    rustup target add aarch64-linux-android
    cargo install cargo-apk
    export ANDROID_HOME=/path/to/Android/Sdk
    export ANDROID_NDK_ROOT=$ANDROID_HOME/ndk/<version>
    cargo apk build --release --lib --target aarch64-linux-android

The APK is written to `target/release/apk/`; install it with `adb install`.

## Logging in
- **Bot token (recommended, allowed by Discord):** create an app at
  discord.com/developers, add the bot to a server, enable "Message Content
  Intent". Tick "This is a bot token". Bots cannot list DMs.
- **User token:** Discord's Terms of Service prohibit third-party clients on
  user accounts and the account can be banned. If you test it, use an alt.
  Untick the bot box. Best-effort and may break.
- The token is stored in a plain file in the app's private storage.

## Not included
Voice, push notifications, friends list, search, threads, typing indicators.
(Voice needs encrypted real-time audio and notifications need Android JNI
code; both are big separate jobs.)

## Written without compiling
This code could not be compiled where it was written. Likely trouble spots:
Slint version differences (`changed viewport-height`, `font-idx <=> ...`,
emoji button labels), image/webp feature flags, and TLS provider features if
two rustls backends get pulled in (see `install_default` in `src/lib.rs`).
